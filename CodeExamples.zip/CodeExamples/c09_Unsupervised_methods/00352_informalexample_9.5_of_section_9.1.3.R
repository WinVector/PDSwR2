# informalexample 9.5 of section 9.1.3 
# (informalexample 9.5 of section 9.1.3)  : Unsupervised methods : Cluster analysis : Hierarchical clustering with hclust 

rect.hclust(pfit, k=5)

