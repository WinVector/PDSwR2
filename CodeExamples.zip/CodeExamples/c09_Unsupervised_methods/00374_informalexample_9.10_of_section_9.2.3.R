# informalexample 9.10 of section 9.2.3 
# (informalexample 9.10 of section 9.2.3)  : Unsupervised methods : Association rules : Mining association rules with the arules package 

inspect(head((sort(rules, by="confidence")), n=5))

