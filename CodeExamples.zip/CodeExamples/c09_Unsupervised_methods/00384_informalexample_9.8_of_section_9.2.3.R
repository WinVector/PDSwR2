# informalexample 9.8 of section 9.2.3 
# (informalexample 9.8 of section 9.2.3)  : Unsupervised methods : Association rules : Mining association rules with the arules package 

bookFreq <- itemFrequency(bookbaskets)
## summary(bookFreq)
##      Min.   1st Qu.    Median      Mean   3rd Qu.      Max.
## 1.086e-05 1.086e-05 1.086e-05 5.035e-05 3.257e-05 2.716e-02

sum(bookFreq)
## [1] 11.09909

