# informalexample 4.1 of section 4.1.3 
# (informalexample 4.1 of section 4.1.3)  : Managing data : Cleaning data : The vtreat package for automatically treating missing variables 

varlist <- setdiff(colnames(customer_data), c("custid", "health_ins"))

