# informalexample 8.5 of section 8.1.3 
# (informalexample 8.5 of section 8.1.3)  : Unsupervised methods : Cluster analysis : Hierarchical clustering with hclust 

rect.hclust(pfit, k=5)

