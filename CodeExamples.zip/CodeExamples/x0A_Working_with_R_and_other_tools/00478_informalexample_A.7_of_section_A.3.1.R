# informalexample A.7 of section A.3.1 
# (informalexample A.7 of section A.3.1)  : Working with R and other tools : Using databases with R : TODO: new db section 

options(gsubfn.engine = "R")

