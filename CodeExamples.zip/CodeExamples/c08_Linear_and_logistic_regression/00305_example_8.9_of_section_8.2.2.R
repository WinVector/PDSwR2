# example 8.9 of section 8.2.2 
# (example 8.9 of section 8.2.2)  : Linear and logistic regression : Using logistic regression : Building a logistic regression model 
# Title: Fitting the logistic regression model 

print(fmla)

## atRisk ~ PWGT + UPREVIS + CIG_REC + GESTREC3 + DPLURAL + ULD_MECO + 
##     ULD_PRECIP + ULD_BREECH + URF_DIAB + URF_CHYPER + URF_PHYPER + 
##     URF_ECLAM
## <environment: base>

model <- glm(fmla, data=train, family=binomial(link="logit"))

