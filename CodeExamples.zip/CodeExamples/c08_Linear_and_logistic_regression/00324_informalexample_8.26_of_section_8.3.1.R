# informalexample 8.26 of section 8.3.1 
# (informalexample 8.26 of section 8.3.1)  : Linear and logistic regression : Regularization : An Example of Quasi-separation 

## Warning: glm.fit: fitted probabilities numerically 0 or 1 occurred

