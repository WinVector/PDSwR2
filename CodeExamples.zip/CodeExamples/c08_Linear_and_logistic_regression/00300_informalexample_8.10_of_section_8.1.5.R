# informalexample 8.10 of section 8.1.5 
# (informalexample 8.10 of section 8.1.5)  : Linear and logistic regression : Using linear regression : Reading the model summary and characterizing coefficient quality 

modelResidualError <- sqrt(sum(residuals(model)^2)/df)

