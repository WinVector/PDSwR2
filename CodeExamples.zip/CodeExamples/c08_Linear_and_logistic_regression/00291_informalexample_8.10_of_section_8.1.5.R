# informalexample 8.10 of section 8.1.5 
# (informalexample 8.10 of section 8.1.5)  : Linear and logistic regression : Using linear regression : Reading the model summary and characterizing coefficient quality 

(df <-  nrow(dtrain) - nrow(summary(model)$coefficients) )
## [1] 11186

