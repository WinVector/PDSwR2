# informalexample A.3 of section A.2.1 
# (informalexample A.3 of section A.2.1)  : Starting with R and other tools : Starting with R : Primary features of R 

x <- 2
x < - 3
## [1] FALSE
print(x)
## [1] 2

