# informalexample Front Matter.1 of section Front Matter.5.6 
# (informalexample Front Matter.1 of section Front Matter.5.6)  : Practical Data Science with R : About this book : Working with this book 

git clone https://github.com/WinVector/PDSwR2.git

