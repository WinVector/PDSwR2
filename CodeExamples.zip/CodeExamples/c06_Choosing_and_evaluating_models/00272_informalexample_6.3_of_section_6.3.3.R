# informalexample 6.3 of section 6.3.3 
# (informalexample 6.3 of section 6.3.3)  : Choosing and evaluating models : Local Interpretable Model-Agnostic Explanations (LIME) for explaining model predictions : LIME for Text Classification 

list(text = texts[12], label = labels[12])
## $text
## train_385 
##                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               train_385 
## "Jameson Parker And Marilyn Hassett are the screen's most unbelievable couple since John 
## Travolta and Lily Tomlin. Larry Peerce's direction wavers uncontrollably between black farce and
## Roman tragedy. Robert Klein certainly think it's the former and his self-centered performance in 
## a minor role underscores the total lack of balance and chemistry between the players in the film. 
## Normally, I don't like to let myself get so ascerbic, but The Bell Jar is one of my all-time 
## favorite books, and to watch what they did with it makes me literally crazy." 
## 
## $label
## train_385 
##         0

