# informalexample 6.9 of section 6.3.5 
# (informalexample 6.9 of section 6.3.5)  : Choosing and evaluating models : Local Interpretable Model-Agnostic Explanations (LIME) for explaining model predictions : Explaining the classifier's predictions 

plot_text_explanations(explanation)

