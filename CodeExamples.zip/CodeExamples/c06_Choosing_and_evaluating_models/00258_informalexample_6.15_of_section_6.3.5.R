# informalexample 6.15 of section 6.3.5 
# (informalexample 6.15 of section 6.3.5)  : Choosing and evaluating models : Local Interpretable Model-Agnostic Explanations (LIME) for explaining model predictions : Explaining the classifier's predictions 

predict(model, newdata=make_matrix(sample_case[2], vocab))
                                ## [1] 0.6052929

