# informalexample 6.7 of section 6.3.1 
# (informalexample 6.7 of section 6.3.1)  : Choosing and evaluating models : Evaluating models : Evaluating classification models 

confmat_spam[1,1] / (confmat_spam[1,1] + confmat_spam[1,2])
## [1] 0.9496403

