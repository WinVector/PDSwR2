# informalexample 6.10 of section 6.3.3 
# (informalexample 6.10 of section 6.3.3)  : Choosing and evaluating models : Evaluating models : Evaluating probability models 

log_likelihood = sum(y * log(py) + (1-y) * log(1 - py))

