# example 7.19 of section 7.4.2 
# (example 7.19 of section 7.4.2)  : Advanced Data Preparation : Building models using many variables : Using decision trees 
# Title: Plotting the decision tree 

par(cex=0.7)
plot(tmodel)
text(tmodel)

