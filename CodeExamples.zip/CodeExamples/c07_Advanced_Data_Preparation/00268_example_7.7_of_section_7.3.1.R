# example 7.7 of section 7.3.1 
# (example 7.7 of section 7.3.1)  : Advanced Data Preparation : Building single-variable models : Building single variable models from categorical features 
# Title: Churn rates grouped by variable 218 codes 

table218[, 2]/sum(table218)
                                        
##       cJvF       UYBR       <NA> 
## 0.05961398 0.08306808 0.26434783

