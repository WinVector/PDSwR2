# informalexample 7.12 of section 7.5.7 
# (informalexample 7.12 of section 7.5.7)  : Advanced Data Preparation : The vtreat package in general : The treatment plan 

head(vtreat::prepare(treatments, d))

##     x_spline    x          y
## 1 0.02999707 0.03 0.02999550
## 2 0.05996439 0.06 0.05996401
## 3 0.08987782 0.09 0.08987855
## 4 0.11971070 0.12 0.11971221
## 5 0.14943638 0.15 0.14943813
## 6 0.17902820 0.18 0.17902957

