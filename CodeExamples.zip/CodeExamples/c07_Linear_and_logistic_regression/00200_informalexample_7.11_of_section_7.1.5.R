# informalexample 7.11 of section 7.1.5 
# (informalexample 7.11 of section 7.1.5)  : Linear and logistic regression : Using linear regression : Reading the model summary and characterizing coefficient quality 

(modelResidualError <- sqrt(sum(residuals(model)^2) / df))
## [1] 0.2687895

