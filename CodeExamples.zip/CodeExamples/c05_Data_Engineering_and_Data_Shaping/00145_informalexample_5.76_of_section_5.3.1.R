# informalexample 5.76 of section 5.3.1 
# (informalexample 5.76 of section 5.3.1)  : Data Engineering and Data Shaping : Aggregating Transforms : Replacing missing values. 

dplyr::coalesce(data$sensor1, data$sensor2)

