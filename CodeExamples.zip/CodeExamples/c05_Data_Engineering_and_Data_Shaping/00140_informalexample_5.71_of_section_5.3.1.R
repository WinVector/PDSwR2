# informalexample 5.71 of section 5.3.1 
# (informalexample 5.71 of section 5.3.1)  : Data Engineering and Data Shaping : Aggregating Transforms : Scenario 

packageVersion("dplyr")
## [1] ‘0.7.7’
dplyr::coalesce(data$sensor1, data$sensor2)

