# informalexample 5.158 of section 5.4.2 
# (informalexample 5.158 of section 5.4.2)  : Data Engineering and Data Shaping : Multi Table Data Transforms : Princpled methods to combine data from multiple tables 

trades <- data.table(price = c(5.5, 9),
                     quantity = c(100, 200),
                     when = c(3, 9))

print(trades)

