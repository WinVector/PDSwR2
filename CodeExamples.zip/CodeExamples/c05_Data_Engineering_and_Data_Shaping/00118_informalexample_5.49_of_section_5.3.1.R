# informalexample 5.49 of section 5.3.1 
# (informalexample 5.49 of section 5.3.1)  : Data Engineering and Data Shaping : Aggregating Transforms : Combining many rows into summary rows 

library("datasets")
library("ggplot2")

head(iris)

