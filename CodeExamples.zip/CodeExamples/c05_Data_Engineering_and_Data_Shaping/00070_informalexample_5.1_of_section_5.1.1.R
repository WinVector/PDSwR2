# informalexample 5.1 of section 5.1.1 
# (informalexample 5.1 of section 5.1.1)  : Data Engineering and Data Shaping : Data Selection : Subsetting Rows and Columns 

library("datasets")
library("ggplot2")

summary(iris)

