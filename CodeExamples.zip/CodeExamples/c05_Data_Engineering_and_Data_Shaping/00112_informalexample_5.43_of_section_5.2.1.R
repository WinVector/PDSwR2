# informalexample 5.43 of section 5.2.1 
# (informalexample 5.43 of section 5.2.1)  : Data Engineering and Data Shaping : Basic Data Transforms : Context 

library("datasets")
library("ggplot2")

summary(airquality)

