# informalexample 5.119 of section 5.4.1 
# (informalexample 5.119 of section 5.4.1)  : Data Engineering and Data Shaping : Multi Table Data Transforms : Combining two or more ordered data.frames quickly 

cbind(productTable, salesTable[,-1])

