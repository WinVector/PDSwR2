# informalexample 5.2 of section 5.1.1 
# (informalexample 5.2 of section 5.1.1)  : Data Engineering and Data Shaping : Data Selection : Subsetting Rows and Columns 

head(iris)

