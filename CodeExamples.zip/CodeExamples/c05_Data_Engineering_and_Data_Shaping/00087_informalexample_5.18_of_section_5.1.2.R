# informalexample 5.18 of section 5.1.2 
# (informalexample 5.18 of section 5.1.2)  : Data Engineering and Data Shaping : Data Selection : Removing records with incomplete data 

nrow(clean_base_1)

