# informalexample 5.22 of section 5.1.2 
# (informalexample 5.22 of section 5.1.2)  : Data Engineering and Data Shaping : Data Selection : Removing records with incomplete data 

clean_base_2 = na.omit(msleep)
nrow(clean_base_2)

