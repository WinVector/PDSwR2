# informalexample 5.73 of section 5.3.2 
# (informalexample 5.73 of section 5.3.2)  : Data Engineering and Data Shaping : Aggregating Transforms : Combining many rows into summary rows 

library("datasets")
library("ggplot2")

head(iris)

