# informalexample 5.49 of section 5.2.3 
# (informalexample 5.49 of section 5.2.3)  : Data Engineering and Data Shaping : Basic Data Transforms : Parametric programming 

d <- data.frame(x = 1:2, y = 3:4, zero = 5:6)

print(d$x)

