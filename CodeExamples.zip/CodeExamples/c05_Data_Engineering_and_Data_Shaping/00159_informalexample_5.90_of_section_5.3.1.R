# informalexample 5.90 of section 5.3.1 
# (informalexample 5.90 of section 5.3.1)  : Data Engineering and Data Shaping : Aggregating Transforms : Scenario 

dplyr::coalesce(data$sensor1, data$sensor2)

