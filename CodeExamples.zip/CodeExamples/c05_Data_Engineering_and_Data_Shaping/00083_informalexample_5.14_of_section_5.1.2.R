# informalexample 5.14 of section 5.1.2 
# (informalexample 5.14 of section 5.1.2)  : Data Engineering and Data Shaping : Data Selection : Removing records with incomplete data 

library("ggplot2")
data(msleep)

str(msleep)

