# informalexample 5.53 of section 5.2.3 
# (informalexample 5.53 of section 5.2.3)  : Data Engineering and Data Shaping : Basic Data Transforms : Parametric programming 

d$z

