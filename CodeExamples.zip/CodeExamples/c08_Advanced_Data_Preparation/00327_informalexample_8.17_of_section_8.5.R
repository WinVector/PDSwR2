# informalexample 8.17 of section 8.5 
# (informalexample 8.17 of section 8.5)  : Advanced Data Preparation : Preparing data for regression modeling 

auto_mpg <- readRDS('auto_mpg.RDS')

knitr::kable(head(auto_mpg)) 	# Note: 1

# Note 1: 
#   Take a quick look at the data. 

