# informalexample 8.13 of section 8.5.8 
# (informalexample 8.13 of section 8.5.8)  : Advanced Data Preparation : The vtreat package in general : The variable score frame 

treatments$scoreFrame

##    varName varMoves        rsq         sig needsSplit extraModelDegrees
## 1 x_spline     TRUE 0.99999808 0.000000000       TRUE              1000
## 2        x     TRUE 0.01013373 0.001435232      FALSE                 0
##   origName   code
## 1        x spline
## 2        x  clean

