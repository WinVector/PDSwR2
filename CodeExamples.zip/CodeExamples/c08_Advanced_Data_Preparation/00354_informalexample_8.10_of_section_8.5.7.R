# informalexample 8.10 of section 8.5.7 
# (informalexample 8.10 of section 8.5.7)  : Advanced Data Preparation : The vtreat package in general : The treatment plan 

class(treatments)

## [1] "treatmentplan"

