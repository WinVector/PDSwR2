# informalexample 8.2 of section 8.2.1 
# (informalexample 8.2 of section 8.2.1)  : Advanced Data Preparation : KDD and KDD Cup 2009 : Getting started with KDD Cup 2009 data 

outcome_summary["1"] / sum(outcome_summary) 	# Note: 1 
#          1 
# 0.07347764

# Note 1: 
#   Estimate observed churn rate or prevalence. 

