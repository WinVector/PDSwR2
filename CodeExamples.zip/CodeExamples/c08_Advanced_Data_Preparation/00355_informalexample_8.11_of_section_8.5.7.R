# informalexample 8.11 of section 8.5.7 
# (informalexample 8.11 of section 8.5.7)  : Advanced Data Preparation : The vtreat package in general : The treatment plan 

print(treatments)

##   origName  varName   code        rsq         sig extraModelDegrees
## 1        x x_spline spline 0.99999808 0.000000000              1000
## 2        x        x  clean 0.01013373 0.001435232                 0

