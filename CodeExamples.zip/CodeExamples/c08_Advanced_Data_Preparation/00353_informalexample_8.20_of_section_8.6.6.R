# informalexample 8.20 of section 8.6.6 
# (informalexample 8.20 of section 8.6.6)  : Advanced Data Preparation : The vtreat package in general : The variable score frame 

plan4$scoreFrame

#   varName varMoves rsq       sig needsSplit extraModelDegrees origName code
# 1 x2_catB     TRUE   1 0.0506719       TRUE                 2       x2 catB

