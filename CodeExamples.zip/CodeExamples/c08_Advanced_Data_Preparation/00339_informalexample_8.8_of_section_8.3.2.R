# informalexample 8.8 of section 8.3.2 
# (informalexample 8.8 of section 8.3.2)  : Advanced Data Preparation : Basic data preparation for classification : Properly using the treatment plan 

dCal_treated <- prepare(treatment_plan, 
                        dCal,
                        parallelCluster = cl)

