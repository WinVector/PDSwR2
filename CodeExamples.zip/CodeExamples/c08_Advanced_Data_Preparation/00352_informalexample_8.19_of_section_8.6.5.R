# informalexample 8.19 of section 8.6.5 
# (informalexample 8.19 of section 8.6.5)  : Advanced Data Preparation : The vtreat package in general : The treatment plan 

class(plan4)
# [1] "treatmentplan"

names(plan4)

# [1] "treatments"    "scoreFrame"    "outcomename"   "vtreatVersion" "outcomeType"  
# [6] "outcomeTarget" "meanY"         "splitmethod"

