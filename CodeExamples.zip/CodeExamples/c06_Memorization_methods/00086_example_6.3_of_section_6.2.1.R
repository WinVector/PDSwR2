# example 6.3 of section 6.2.1 
# (example 6.3 of section 6.2.1)  : Memorization methods : Building single-variable models : Using categorical features 
# Title: Churn rates grouped by variable 218 codes 

print(table218[,2]/(table218[,1]+table218[,2]))
##       cJvF       UYBR       <NA>
## 0.05994389 0.08223821 0.26523297

