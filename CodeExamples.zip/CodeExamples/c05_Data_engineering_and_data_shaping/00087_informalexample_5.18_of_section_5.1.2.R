# informalexample 5.18 of section 5.1.2 
# (informalexample 5.18 of section 5.1.2)  : Data engineering and data shaping : Data selection : Removing records with incomplete data 

nrow(clean_base_1)

