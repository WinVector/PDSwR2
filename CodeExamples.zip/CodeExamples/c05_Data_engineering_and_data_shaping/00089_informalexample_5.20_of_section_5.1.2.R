# informalexample 5.20 of section 5.1.2 
# (informalexample 5.20 of section 5.1.2)  : Data engineering and data shaping : Data selection : Removing records with incomplete data 

clean_base_2 = na.omit(msleep)
nrow(clean_base_2)

