# informalexample 5.75 of section 5.4.1 
# (informalexample 5.75 of section 5.4.1)  : Data engineering and data shaping : Multi-table data transforms : Combining two or more ordered data frames quickly 

cbind(productTable, salesTable[, -1])

