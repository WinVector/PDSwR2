# informalexample 5.7 of section 5.1.1 
# (informalexample 5.7 of section 5.1.1)  : Data engineering and data shaping : Data selection : Sub-setting rows and columns 

iris_base <- iris[rows_we_want, columns_we_want, drop = FALSE]

# after
head(iris_base)

