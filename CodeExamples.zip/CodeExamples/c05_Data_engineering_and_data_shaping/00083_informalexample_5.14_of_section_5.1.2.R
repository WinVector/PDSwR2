# informalexample 5.14 of section 5.1.2 
# (informalexample 5.14 of section 5.1.2)  : Data engineering and data shaping : Data selection : Removing records with incomplete data 

summary(msleep)

