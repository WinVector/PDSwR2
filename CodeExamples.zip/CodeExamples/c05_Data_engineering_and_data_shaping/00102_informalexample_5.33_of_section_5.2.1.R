# informalexample 5.33 of section 5.2.1 
# (informalexample 5.33 of section 5.2.1)  : Data engineering and data shaping : Basic data transforms : Add new columns 

library("datasets")
library("ggplot2")

summary(airquality)

