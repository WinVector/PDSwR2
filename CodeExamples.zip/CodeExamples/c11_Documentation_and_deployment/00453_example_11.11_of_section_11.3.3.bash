# example 11.11 of section 11.3.3 
# (example 11.11 of section 11.3.3)  : Documentation and deployment : Using comments and version control for running documentation : Using version control to explore your project 
# Title: Viewing detailed project history 

git log --graph --name-status
* commit 4efb2b78dfefee6eb8b48f62280c5de63ecb26b9 (HEAD -> master, origin/master)
| Author: John Mount <jmount@win-vector.com>
| Date:   Wed Apr 24 16:22:43 2019 -0700
| 
|     Add Nina's Shiny example
| 
| A     Buzz/buzzapp/buzzapp.Rproj
| A     Buzz/buzzapp/buzzutils.R
| A     Buzz/buzzapp/server.R
| A     Buzz/buzzapp/ui.R
| 
* commit ea11fcfa3f04dca26e2e6a031c55488926146259
| Author: John Mount <jmount@win-vector.com>
| Date:   Wed Apr 24 11:01:47 2019 -0700
| 
|     rebuild zip
| 
| M     CodeExamples.zip
|

