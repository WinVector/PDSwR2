# informalexample 11.1 of section 11.2.1 
# (informalexample 11.1 of section 11.2.1)  : Documentation and deployment : Using R markdown to produce milestone documentation : What is R markdown? 

rmarkdown::render("Buzz_score_example.Rmd", rmarkdown::html_document())

