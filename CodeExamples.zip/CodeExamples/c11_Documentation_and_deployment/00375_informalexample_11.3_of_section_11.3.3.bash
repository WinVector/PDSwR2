# informalexample 11.3 of section 11.3.3 
# (informalexample 11.3 of section 11.3.3)  : Documentation and deployment : Using comments and version control for running documentation : Using version control to explore your project 

git log --name-status -- Buzz/buzz.pdf
commit 96503d8ca35a61ed9765edff9800fc9302554a3b
Author: John Mount <jmount@win-vector.com>
Date:   Wed Apr 17 16:41:48 2019 -0700

    fix links and re-build Buzz example

D       Buzz/buzz.pdf

