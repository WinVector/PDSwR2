# example 11.8 of section 11.3.3 
# (example 11.8 of section 11.3.3)  : Documentation and deployment : Using comments and version control for running documentation : Using version control to explore your project 
# Title: Finding who committed what 

git blame Buzz/buzzapp/server.R 
4efb2b78 (John Mount 2019-04-24 16:22:43 -0700  1) #
4efb2b78 (John Mount 2019-04-24 16:22:43 -0700  2) # This is the server logic of a Shiny web application. You can run the 
4efb2b78 (John Mount 2019-04-24 16:22:43 -0700  3) # application by clicking 'Run App' above.
4efb2b78 (John Mount 2019-04-24 16:22:43 -0700  4) #

