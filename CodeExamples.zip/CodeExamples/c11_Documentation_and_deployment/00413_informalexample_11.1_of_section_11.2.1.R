# informalexample 11.1 of section 11.2.1 
# (informalexample 11.1 of section 11.2.1)  : Documentation and deployment : Using knitr to produce milestone documentation : What is knitr? 

library(knitr)
knit('simple.Rmd')

