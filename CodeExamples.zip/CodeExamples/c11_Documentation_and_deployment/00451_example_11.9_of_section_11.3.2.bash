# example 11.9 of section 11.3.2 
# (example 11.9 of section 11.3.2)  : Documentation and deployment : Using comments and version control for running documentation : Using version control to record history 
# Title: Checking your project status 

$ git status
On branch master
Your branch is up to date with 'origin/master'.

nothing to commit, working tree clean

