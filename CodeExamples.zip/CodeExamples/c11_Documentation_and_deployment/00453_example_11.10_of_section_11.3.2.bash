# example 11.10 of section 11.3.2 
# (example 11.10 of section 11.3.2)  : Documentation and deployment : Using comments and version control for running documentation : Using version control to record history 
# Title: Checking your project history 

$ git log
commit d22572281d40522bc6ab524bbdee497964ff4af0 (HEAD -> master, origin/master)
Author: John Mount <jmount@win-vector.com>
Date:   Tue Apr 16 16:24:23 2019 -0700

    technical edits ch7

