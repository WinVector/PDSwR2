# example 11.14 of section 11.3.4 
# (example 11.14 of section 11.3.4)  : Documentation and deployment : Using comments and version control for running documentation : Using version control to share work 
# Title: git remote 

$ git remote --verbose
origin  git@github.com:WinVector/PDSwR2.git (fetch)
origin  git@github.com:WinVector/PDSwR2.git (push)

