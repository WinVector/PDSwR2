# informalexample 8.5 of section 8.3.1 
# (informalexample 8.5 of section 8.3.1)  : Advanced data preparation : Basic data preparation for classification : The variable score frame 

t(subset(score_frame, origName == "Var218"))

#                   389            390            488                 489                
# varName           "Var218_catP"  "Var218_catB"  "Var218_lev_x_cJvF" "Var218_lev_x_UYBR"
# varMoves          "TRUE"         "TRUE"         "TRUE"              "TRUE"             
# rsq               "0.011014574"  "0.012245152"  "0.005295590"       "0.001970131"      
# sig               "2.602574e-52" "5.924945e-58" "4.902238e-26"      "1.218959e-10"     
# needsSplit        " TRUE"        " TRUE"        "FALSE"             "FALSE"            
# extraModelDegrees "2"            "2"            "0"                 "0"                
# origName          "Var218"       "Var218"       "Var218"            "Var218"           
# code              "catP"         "catB"         "lev"               "lev"

