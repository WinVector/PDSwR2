# informalexample 8.26 of section 8.6.5 
# (informalexample 8.26 of section 8.6.5)  : Advanced data preparation : Mastering the vtreat package : The treatment plan 

plan4$scoreFrame

#   varName varMoves rsq       sig needsSplit extraModelDegrees origName code
# 1 x2_catB     TRUE   1 0.0506719       TRUE                 2       x2 catB

