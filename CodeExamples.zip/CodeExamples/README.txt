
Example code and data for "Practical Data Science with R 2nd Edition" by Nina Zumel and John Mount, Manning 2019.

Code examples license:
  This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
  http://creativecommons.org/licenses/by-nc-sa/4.0/
  No guarantee, indemnification or claim of fitness is made regarding any of these items.
  No claim of license on works of others or derived data.
