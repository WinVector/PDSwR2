# informalexample B.3 of section B.2.4 
# (informalexample B.3 of section B.2.4)  : Important statistical concepts : Statistical theory : Specialized statistical tests 

sigr::wrapCorTest(ctest)
                
# [1] "Spearman's rank correlation rho: (r=0.03083, p=n.s.)."

